package biomesoplenty.common.biome.decoration;

import biomesoplenty.api.biome.BiomeFeatures;

public class EndBiomeFeatures extends BiomeFeaturesBase
{
    
}
