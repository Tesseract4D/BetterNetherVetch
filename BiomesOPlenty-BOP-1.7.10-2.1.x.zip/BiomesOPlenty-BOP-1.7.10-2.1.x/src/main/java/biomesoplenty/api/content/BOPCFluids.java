package biomesoplenty.api.content;

import net.minecraftforge.fluids.Fluid;

public class BOPCFluids 
{
	public static Fluid poison;
	public static Fluid blood;
	public static Fluid honey;
}
