package biomesoplenty.api.content;

import net.minecraft.potion.Potion;

public class BOPCPotions 
{
	public static Potion paralysis;
	public static Potion possession;
}
