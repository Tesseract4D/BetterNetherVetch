package biomesoplenty;



public class CommonProxy 
{
	//Client Only
	public void registerRenderers() 
	{
	}
	
	public void spawnParticle(String string, double x, double y, double z, Object... args)
	{
	}
	
	public int addArmor(String armor)
	{
		return 0;
	}
}