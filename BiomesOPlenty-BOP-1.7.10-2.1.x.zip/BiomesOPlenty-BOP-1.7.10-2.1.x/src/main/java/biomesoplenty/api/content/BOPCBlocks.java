package biomesoplenty.api.content;

import net.minecraft.block.Block;

public class BOPCBlocks 
{
	public static Block mud;
	public static Block driedDirt;
	public static Block rocks;
	public static Block ash;
	public static Block flesh;
	public static Block plants;
	public static Block lilyBop;
	public static Block flowers;
	public static Block flowers2;
	public static Block stoneFormations;
	public static Block mushrooms;
	public static Block willow;
	public static Block ivy;
	public static Block treeMoss;
	public static Block flowerVine;
	public static Block wisteria;
	public static Block foliage;
	public static Block fruitBop;
	public static Block turnip;
	
	public static Block coral1;
	public static Block coral2;

	public static Block ashStone;
	public static Block hardIce;
    
	public static Block appleLeaves;
	public static Block persimmonLeaves;

	public static Block moss;
	public static Block bamboo;

	public static Block mudBricks;
	
	public static Block originGrass;
	public static Block longGrass;
	public static Block overgrownNetherrack;
	
	public static Block bopGrass;
	
	public static Block newBopGrass;
	public static Block newBopDirt;
	public static Block newBopFarmland;
    
	public static Block logs1;
	public static Block logs2;
	public static Block logs3;
	public static Block logs4;
	
	public static Block leaves1;
	public static Block leaves2;
	public static Block leaves3;
	public static Block leaves4;
	
	public static Block petals;
	
	public static Block saplings;
	public static Block colorizedSaplings;

	public static Block hardSand;
	public static Block hardDirt;
	
	public static Block biomeBlock;
	
	public static Block crystal;
	
	public static Block gemOre;
	
	public static Block cragRock;
	
	public static Block hive;
	public static Block honeyBlock;
	
	public static Block bones;
	public static Block grave;
	
	public static Block planks;

	public static Block woodenSingleSlab1;
	public static Block woodenDoubleSlab1;
	
	public static Block woodenSingleSlab2;
	public static Block woodenDoubleSlab2;
	
	public static Block stoneSingleSlab;
	public static Block stoneDoubleSlab;

	public static Block sacredoakStairs;
	public static Block cherryStairs;
	public static Block darkStairs;
	public static Block firStairs;
	public static Block etherealStairs;
	public static Block magicStairs;
	public static Block mangroveStairs;
	public static Block palmStairs;
	public static Block redwoodStairs;
	public static Block willowStairs;
	public static Block pineStairs;
	public static Block hellBarkStairs;
	public static Block jacarandaStairs;
	public static Block mahoganyStairs;

	public static Block mudBricksStairs;
	
	public static Block colorizedLeaves1;
	public static Block colorizedLeaves2;
	
	//Fluid blocks
	public static Block poison;
	public static Block blood;
	public static Block honey;
}
