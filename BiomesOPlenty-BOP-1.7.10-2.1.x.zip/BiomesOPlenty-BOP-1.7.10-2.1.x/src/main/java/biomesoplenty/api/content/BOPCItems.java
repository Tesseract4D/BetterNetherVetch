package biomesoplenty.api.content;

import net.minecraft.item.Item;

public class BOPCItems 
{
	public static Item food;
	public static Item turnipSeeds;
	public static Item misc;
	public static Item gems;
	public static Item mudball;
	public static Item jarEmpty;
	public static Item jarFilled;
	public static Item dartBlower;
	public static Item dart;
	public static Item ancientStaff;
	public static Item enderporter;
	public static Item record_wanderer;
	public static Item record_corruption;
	public static Item biomeFinder;
	public static Item biomeEssence;
	
	public static Item bopBucket;
	
	public static Item swordMud;
	public static Item shovelMud;
	public static Item pickaxeMud;
	public static Item axeMud;
	public static Item hoeMud;
	
	public static Item swordAmethyst;
	public static Item shovelAmethyst;
	public static Item pickaxeAmethyst;
	public static Item axeAmethyst;
	public static Item hoeAmethyst;
	
	public static Item scytheWood;
	public static Item scytheStone;
	public static Item scytheIron;
	public static Item scytheGold;
	public static Item scytheDiamond;
	public static Item scytheMud;
	public static Item scytheAmethyst;
	
	public static Item helmetMud;
	public static Item chestplateMud;
	public static Item leggingsMud;
	public static Item bootsMud;
	
	public static Item helmetAmethyst;
	public static Item chestplateAmethyst;
	public static Item leggingsAmethyst;
	public static Item bootsAmethyst;

	public static Item flowerBand;
	public static Item flippers;
	public static Item wadingBoots;
}
