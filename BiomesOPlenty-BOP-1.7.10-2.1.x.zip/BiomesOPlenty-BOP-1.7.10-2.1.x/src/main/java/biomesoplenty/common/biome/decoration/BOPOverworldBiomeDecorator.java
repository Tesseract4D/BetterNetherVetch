package biomesoplenty.common.biome.decoration;

import biomesoplenty.api.biome.BOPBiome;
import biomesoplenty.api.biome.BOPBiomeDecorator;

public class BOPOverworldBiomeDecorator extends BOPBiomeDecorator<OverworldBiomeFeatures>
{
	public BOPOverworldBiomeDecorator() 
	{
		super(OverworldBiomeFeatures.class);
	}
}
